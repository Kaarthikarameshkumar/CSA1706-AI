import { useState, useRef, useCallback, createContext, useContext } from "react";
import Papa from "papaparse";
import {
  preprocess, buildVocab, trainNaiveBayes, trainLogisticRegression, trainSVM,
  predict, evaluate, detectLabelMap, normalizeLabel,
} from "./nlp";
import type { TrainedModel, EvalResult, PredictResult, Vocab, LabelMap, AlgoName } from "./nlp";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen = "home"|"about"|"dataset"|"preprocessing"|"training"|"detection"|"dashboard"|"results";
type Row = Record<string, string>;

interface Prediction {
  id: number; article: string; processedText: string;
  result: PredictResult; algo: AlgoName; date: string;
}

interface ModelEntry { algo: AlgoName; model: TrainedModel; eval: EvalResult }

interface AppState {
  dataset: Row[]; textCol: string; labelCol: string; lmap: LabelMap | null;
  vocab: Vocab | null; models: ModelEntry[]; predictions: Prediction[];
  bestModel: ModelEntry | null;
  setDataset(rows: Row[], tc: string, lc: string, lm: LabelMap): void;
  setVocab(v: Vocab): void;
  addModel(m: ModelEntry): void;
  clearModels(): void;
  addPrediction(p: Prediction): void;
  deletePrediction(id: number): void;
}

const Ctx = createContext<AppState>({} as AppState);
const useApp = () => useContext(Ctx);

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isFake(label: string) {
  const l = label.trim().toLowerCase();
  return l === "fake" || l === "0" || l === "false";
}

function riskLevel(conf: number, fake: boolean) {
  if (fake) return conf > 90 ? "Critical" : conf > 70 ? "High" : "Medium";
  return conf > 90 ? "Very Low" : conf > 70 ? "Low" : "Medium";
}

function pct(n: number) { return (n * 100).toFixed(2) + "%"; }

// ─── Icons ────────────────────────────────────────────────────────────────────

const I = {
  Home: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
  Info: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>,
  Database: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>,
  Cpu: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/></svg>,
  Brain: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 4.44-1.66z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-4.44-1.66z"/></svg>,
  Search: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  BarChart: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>,
  Trend: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>,
  Shield: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  Chevron: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>,
  Arrow: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>,
  Check: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  Warn: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
  Upload: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>,
  Download: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="8 17 12 21 16 17"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"/></svg>,
  User: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  X: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  Trash: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>,
  Award: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>,
  Zap: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
};

// ─── UI Primitives ────────────────────────────────────────────────────────────

function Card({ children, className = "", style = {} }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return <div className={`rounded-xl p-5 ${className}`} style={{ background: "#0d1526", border: "1px solid rgba(56,189,248,0.09)", ...style }}>{children}</div>;
}

function Btn({ children, variant = "primary", onClick, disabled, className = "" }: {
  children: React.ReactNode; variant?: "primary"|"secondary"|"ghost"|"danger";
  onClick?: () => void; disabled?: boolean; className?: string;
}) {
  const s = {
    primary:   { background: "linear-gradient(135deg,#0ea5e9,#06b6d4)", color: "#080c18", border: "none" },
    secondary: { background: "rgba(56,189,248,0.08)", color: "#38bdf8", border: "1px solid rgba(56,189,248,0.2)" },
    ghost:     { background: "transparent", color: "#64748b", border: "1px solid rgba(56,189,248,0.09)" },
    danger:    { background: "rgba(239,68,68,0.1)", color: "#ef4444", border: "1px solid rgba(239,68,68,0.2)" },
  }[variant];
  return (
    <button onClick={onClick} disabled={disabled}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed ${className}`}
      style={{ ...s, fontFamily: "Inter,sans-serif" }}>
      {children}
    </button>
  );
}

function Badge({ label, fake }: { label: string; fake: boolean }) {
  return (
    <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-bold font-mono"
      style={fake
        ? { background:"rgba(239,68,68,0.12)", color:"#ef4444", border:"1px solid rgba(239,68,68,0.3)" }
        : { background:"rgba(34,197,94,0.12)",  color:"#22c55e", border:"1px solid rgba(34,197,94,0.3)"  }}>
      {label}
    </span>
  );
}

function KPI({ label, value, color="#38bdf8", icon, sub }: { label:string; value:string; color?:string; icon?:React.ReactNode; sub?:string }) {
  return (
    <Card className="flex flex-col gap-2">
      <div className="flex items-start justify-between">
        <span className="text-xs" style={{ color:"#64748b" }}>{label}</span>
        {icon && <span style={{ color }}>{icon}</span>}
      </div>
      <div className="text-2xl font-bold font-mono leading-none" style={{ color }}>{value}</div>
      {sub && <div className="text-xs" style={{ color:"#64748b" }}>{sub}</div>}
    </Card>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function Sidebar({ active, onNav }: { active: Screen; onNav: (s: Screen) => void }) {
  const { models } = useApp();
  const trained = models.length > 0;
  const nav: { id: Screen; label: string; icon: keyof typeof I }[] = [
    { id:"home",           label:"Home",              icon:"Home"     },
    { id:"about",          label:"About",             icon:"Info"     },
    { id:"dataset",        label:"Dataset",           icon:"Database" },
    { id:"preprocessing",  label:"Text Preprocessing",icon:"Cpu"      },
    { id:"training",       label:"Model Training",    icon:"Brain"    },
    { id:"detection",      label:"Fraud Detection",   icon:"Search"   },
    { id:"dashboard",      label:"Dashboard",         icon:"BarChart" },
    { id:"results",        label:"Results",           icon:"Trend"    },
  ];
  return (
    <aside className="flex flex-col h-full shrink-0" style={{ width:236, background:"#080c18", borderRight:"1px solid rgba(56,189,248,0.08)" }}>
      <div className="p-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background:"linear-gradient(135deg,#0ea5e9,#06b6d4)" }}><I.Shield /></div>
          <div>
            <div className="text-xs font-bold text-white leading-none">Fraud Detection</div>
            <div className="font-mono mt-0.5" style={{ color:"#38bdf8", fontSize:10 }}>SYSTEM v2.0</div>
          </div>
        </div>
      </div>
      <div className="mx-4 mb-3" style={{ height:1, background:"rgba(56,189,248,0.08)" }} />
      <nav className="flex-1 px-3 flex flex-col gap-0.5 overflow-auto">
        {nav.map(({ id, label, icon }) => {
          const Ic = I[icon]; const on = active === id;
          return (
            <button key={id} onClick={() => onNav(id)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium text-left w-full cursor-pointer transition-all"
              style={{ color:on?"#38bdf8":"#64748b", background:on?"rgba(56,189,248,0.08)":"transparent", borderLeft:on?"2px solid #38bdf8":"2px solid transparent" }}>
              <span style={{ opacity:on?1:0.6 }}><Ic /></span>{label}
            </button>
          );
        })}
      </nav>
      <div className="p-4">
        <div className="rounded-lg p-3 mb-3" style={{ background:trained?"rgba(34,197,94,0.06)":"rgba(56,189,248,0.04)", border:`1px solid ${trained?"rgba(34,197,94,0.15)":"rgba(56,189,248,0.1)"}` }}>
          <div className="text-xs font-semibold mb-1" style={{ color:"#64748b" }}>System Status</div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full animate-pulse-glow" style={{ background:trained?"#22c55e":"#38bdf8" }} />
            <span className="text-xs font-medium" style={{ color:trained?"#22c55e":"#38bdf8" }}>
              {trained ? `${models.length} Model(s) Trained ✓` : "Awaiting Training"}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 px-1">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold" style={{ background:"rgba(56,189,248,0.15)", color:"#38bdf8" }}>AI</div>
          <div><div className="text-xs font-medium text-white">Admin User</div><div className="text-xs" style={{ color:"#64748b" }}>NLP Research</div></div>
        </div>
      </div>
    </aside>
  );
}

function Header({ title, sub }: { title: string; sub?: string }) {
  return (
    <div className="flex items-center justify-between py-4 px-8 border-b shrink-0" style={{ borderColor:"rgba(56,189,248,0.08)", background:"rgba(8,12,24,0.95)" }}>
      <div>
        <h1 className="text-lg font-bold text-white">{title}</h1>
        {sub && <p className="text-xs mt-0.5" style={{ color:"#64748b" }}>{sub}</p>}
      </div>
      <div className="flex items-center gap-3">
        <div className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium" style={{ background:"rgba(56,189,248,0.08)", color:"#38bdf8", border:"1px solid rgba(56,189,248,0.15)" }}>NB · LR · SVM</div>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background:"rgba(56,189,248,0.1)", border:"1px solid rgba(56,189,248,0.15)" }}><I.User /></div>
      </div>
    </div>
  );
}

// ─── HOME ─────────────────────────────────────────────────────────────────────

function HomeScreen({ onNav }: { onNav:(s:Screen)=>void }) {
  return (
    <div className="flex-1 overflow-auto">
      <div className="relative overflow-hidden" style={{ background:"linear-gradient(135deg,#080c18 0%,#0a1428 60%,#0d1526 100%)", minHeight:400 }}>
        <div className="absolute inset-0" style={{ backgroundImage:"linear-gradient(rgba(56,189,248,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(56,189,248,0.03) 1px,transparent 1px)", backgroundSize:"32px 32px" }} />
        <div className="max-w-6xl mx-auto px-8 py-14 grid gap-12 items-center" style={{ gridTemplateColumns:"1fr 1fr" }}>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-5 text-xs font-mono" style={{ background:"rgba(56,189,248,0.08)", color:"#38bdf8", border:"1px solid rgba(56,189,248,0.15)" }}>
              <span className="w-1.5 h-1.5 rounded-full animate-pulse-glow" style={{ background:"#38bdf8" }} />
              NLP · Naive Bayes · Logistic Regression · SVM
            </div>
            <h1 className="text-5xl font-extrabold leading-tight mb-4 text-white">Fraud Detection<br />
              <span style={{ background:"linear-gradient(90deg,#38bdf8,#06b6d4)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>System</span>
            </h1>
            <p className="text-base mb-6 leading-relaxed" style={{ color:"#94a3b8" }}>
              Upload a labeled CSV dataset (up to 20,000+ rows), train three ML classifiers, and detect fake news in real time with confidence scores and top keyword explanations.
            </p>
            <div className="flex gap-3">
              <Btn onClick={() => onNav("dataset")}>Get Started <I.Arrow /></Btn>
              <Btn variant="secondary" onClick={() => onNav("detection")}>Try Detection</Btn>
            </div>
          </div>
          <div className="relative flex items-center justify-center" style={{ height:280 }}>
            <div className="absolute w-20 h-20 rounded-2xl flex items-center justify-center z-10" style={{ background:"rgba(56,189,248,0.1)", border:"1px solid rgba(56,189,248,0.3)", boxShadow:"0 0 40px rgba(56,189,248,0.15)" }}><I.Shield /></div>
            {[0,60,120,180,240,300].map((deg, i) => (
              <div key={i} className="absolute" style={{ transform:`rotate(${deg}deg) translateX(100px)` }}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background:"rgba(13,21,38,0.9)", border:"1px solid rgba(56,189,248,0.2)", transform:`rotate(-${deg}deg)` }}>
                  {[<I.Database/>,<I.Cpu/>,<I.Brain/>,<I.BarChart/>,<I.Check/>,<I.Warn/>][i]}
                </div>
              </div>
            ))}
            <div className="absolute w-60 h-60 rounded-full animate-spin-slow" style={{ border:"1px dashed rgba(56,189,248,0.12)" }} />
          </div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-8 py-10">
        <div className="grid grid-cols-3 gap-5 mb-8">
          {[
            { n:"01", t:"Upload CSV Dataset", d:"Upload labeled news CSV (REAL/FAKE, 0/1, or any labels). Auto-detects text and label columns. Supports 20K+ rows.", color:"#38bdf8" },
            { n:"02", t:"Train 3 Models", d:"Trains Naive Bayes, Logistic Regression, and SVM in one click. Shows real accuracy, F1 score, and confusion matrix for each.", color:"#06b6d4" },
            { n:"03", t:"Detect Fake News", d:"Paste any article. The best model (SVM) predicts REAL or FAKE with confidence % and the top keywords behind the decision.", color:"#22c55e" },
          ].map(({ n, t, d, color }) => (
            <Card key={n}>
              <div className="text-xs font-mono font-semibold mb-1" style={{ color }}>{n}</div>
              <h3 className="font-bold text-white mb-1.5">{t}</h3>
              <p className="text-xs leading-relaxed" style={{ color:"#64748b" }}>{d}</p>
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-5">
          {[
            { n:"Naive Bayes", acc:"~85–92%", d:"Probabilistic classifier. Fast, interpretable. Uses Laplace smoothing." },
            { n:"Logistic Regression", acc:"~93–97%", d:"Linear classifier with SGD. Better on correlated TF-IDF features." },
            { n:"SVM (Best)", acc:"~95–99%", d:"Maximum-margin classifier. Pegasos algorithm. Highest accuracy on text." },
          ].map(({ n, acc, d }) => (
            <Card key={n}>
              <div className="text-xs font-mono font-semibold mb-1" style={{ color: n.includes("Best") ? "#22c55e" : "#38bdf8" }}>{acc}</div>
              <h3 className="font-bold text-white mb-1.5">{n}</h3>
              <p className="text-xs leading-relaxed" style={{ color:"#64748b" }}>{d}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── ABOUT ────────────────────────────────────────────────────────────────────

function AboutScreen() {
  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="max-w-5xl mx-auto flex flex-col gap-5">
        <div className="grid grid-cols-2 gap-5">
          {[
            { t:"Naive Bayes", c:"#38bdf8", d:"Multinomial NB computes P(class|words) via Bayes' theorem. Each word in the document contributes log-probability evidence for each class. Implemented with Laplace smoothing so unseen words don't crash predictions. Uses a Map-based vocabulary index for O(1) lookups — critical for 20K records." },
            { t:"Logistic Regression", c:"#06b6d4", d:"Binary classifier trained with mini-batch SGD over TF-IDF features. Uses L2 regularization and a decaying learning rate to prevent overfitting. Sigmoid activation maps the linear score to a probability. Typically outperforms NB when features are correlated." },
            { t:"Linear SVM (Pegasos)", c:"#22c55e", d:"Maximum-margin classifier. Pegasos is an online SGD algorithm that minimises the primal SVM objective with hinge loss. It shrinks weights each step for L2 regularization and only updates when a training example violates the margin. Achieves the highest accuracy on text (~95–99%)." },
            { t:"TF-IDF + Label Detection", c:"#818cf8", d:"Term Frequency × Inverse Document Frequency weights words by discriminativeness. The app auto-detects your label column values — handles REAL/FAKE, 0/1, TRUE/FALSE, and custom labels — and normalises them to FAKE/REAL before training, so no manual configuration is needed." },
          ].map(({ t, c, d }) => (
            <Card key={t}>
              <div className="flex items-center gap-2 mb-3"><div className="w-2 h-2 rounded-full" style={{ background:c }} /><h3 className="font-bold text-white text-sm">{t}</h3></div>
              <p className="text-sm leading-relaxed" style={{ color:"#64748b" }}>{d}</p>
            </Card>
          ))}
        </div>
        <Card>
          <h3 className="font-bold text-white mb-5">System Architecture</h3>
          <div className="flex items-center gap-2 flex-wrap">
            {["CSV Upload","Detect Labels","Preprocess","Build Vocab","TF-IDF","Train NB","Train LR","Train SVM","Evaluate All","Select Best","Predict"].map((lbl, i, arr) => (
              <div key={lbl} className="flex items-center gap-2">
                <div className="px-3 py-2 rounded-lg text-xs font-medium" style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.12)", color:"#94a3b8" }}>{lbl}</div>
                {i < arr.length - 1 && <span style={{ color:"rgba(56,189,248,0.3)" }}><I.Arrow /></span>}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── DATASET ──────────────────────────────────────────────────────────────────

function DatasetScreen() {
  const { dataset, textCol, labelCol, lmap, setDataset } = useApp();
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const parseFile = (file: File) => {
    setError(""); setLoading(true);
    Papa.parse<Row>(file, {
      header: true, skipEmptyLines: true,
      complete: (res) => {
        setLoading(false);
        const rows = res.data as Row[];
        if (!rows.length) { setError("CSV appears to be empty."); return; }
        const cols = Object.keys(rows[0]);

        // Detect text column = longest average content
        const tCol = cols
          .filter(c => /text|content|article|body|news|title/i.test(c))
          .concat(cols.filter(c => {
            const avg = rows.slice(0, 30).reduce((s, r) => s + (r[c] || "").length, 0) / 30;
            return avg > 30;
          }))
          .sort((a, b) => {
            const avgA = rows.slice(0, 30).reduce((s, r) => s + (r[a] || "").length, 0);
            const avgB = rows.slice(0, 30).reduce((s, r) => s + (r[b] || "").length, 0);
            return avgB - avgA;
          })[0] ?? cols[0];

        // Detect label column = low cardinality
        const lCol = cols.find(c => c !== tCol && /label|class|target|category|type/i.test(c))
          ?? cols.find(c => c !== tCol && (() => {
            const u = new Set(rows.slice(0, 200).map(r => (r[c] || "").trim()));
            return u.size >= 2 && u.size <= 6;
          })())
          ?? cols[cols.length - 1];

        const rawLabels = rows.map(r => (r[lCol] || "").trim());
        const lm = detectLabelMap(rawLabels);
        setDataset(rows, tCol, lCol, lm);
      },
      error: () => { setLoading(false); setError("Could not parse CSV. Check the file format."); },
    });
  };

  const fakeCount  = lmap ? dataset.filter(r => r[labelCol]?.trim() === lmap.fakeLabel).length : 0;
  const realCount  = dataset.length - fakeCount;
  const realPct    = dataset.length ? Math.round((realCount / dataset.length) * 100) : 0;
  const circ       = 2 * Math.PI * 42;

  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="max-w-5xl mx-auto flex flex-col gap-5">
        <Card>
          <div onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)}
            onDrop={e => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f?.name.endsWith(".csv")) parseFile(f); else setError("Drop a .csv file."); }}
            onClick={() => fileRef.current?.click()}
            className="rounded-xl flex flex-col items-center justify-center py-10 cursor-pointer"
            style={{ border:`2px dashed ${dragging?"rgba(56,189,248,0.5)":"rgba(56,189,248,0.2)"}`, background:dragging?"rgba(56,189,248,0.05)":"rgba(56,189,248,0.02)" }}>
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3" style={{ background:"rgba(56,189,248,0.08)", border:"1px solid rgba(56,189,248,0.15)" }}>
              <span style={{ color:"#38bdf8" }}><I.Upload /></span>
            </div>
            <div className="font-bold text-white mb-1">{loading ? "Parsing…" : dataset.length ? "Replace Dataset" : "Upload News Dataset"}</div>
            <div className="text-sm mb-3" style={{ color:"#64748b" }}>Supports 20,000+ rows · CSV · Auto-detects REAL/FAKE labels</div>
            <Btn variant="secondary" onClick={() => fileRef.current?.click()} disabled={loading}>{loading?"Loading…":"Choose CSV File"}</Btn>
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) parseFile(f); }} />
          </div>
          {error && <div className="mt-3 text-xs px-3 py-2 rounded-lg" style={{ background:"rgba(239,68,68,0.08)", color:"#ef4444", border:"1px solid rgba(239,68,68,0.2)" }}>{error}</div>}
          {dataset.length > 0 && lmap && (
            <div className="mt-3 text-xs px-3 py-2 rounded-lg flex items-center gap-2" style={{ background:"rgba(34,197,94,0.06)", color:"#22c55e", border:"1px solid rgba(34,197,94,0.2)" }}>
              <I.Check /> {dataset.length.toLocaleString()} rows · Text: "{textCol}" · Label: "{labelCol}" · FAKE="{lmap.fakeLabel}" · REAL="{lmap.realLabel}"
            </div>
          )}
        </Card>

        {dataset.length > 0 && lmap && (
          <>
            <div className="grid grid-cols-4 gap-4">
              <KPI label="Total Records" value={dataset.length.toLocaleString()} icon={<I.Database />} />
              <KPI label="Columns" value={String(Object.keys(dataset[0]).length)} color="#06b6d4" icon={<I.BarChart />} />
              <KPI label="Fake News" value={fakeCount.toLocaleString()} color="#ef4444" icon={<I.Warn />} sub={`label: "${lmap.fakeLabel}"`} />
              <KPI label="Real News" value={realCount.toLocaleString()} color="#22c55e" icon={<I.Check />} sub={`label: "${lmap.realLabel}"`} />
            </div>

            <div className="grid grid-cols-3 gap-5">
              <div className="col-span-2">
                <Card>
                  <h3 className="font-bold text-white mb-4">Dataset Overview</h3>
                  {[
                    { k:"Text Column", v:textCol },
                    { k:"Label Column", v:labelCol },
                    { k:"FAKE label detected", v:`"${lmap.fakeLabel}"` },
                    { k:"REAL label detected", v:`"${lmap.realLabel}"` },
                    { k:"Avg Text Length", v:Math.round(dataset.slice(0,500).reduce((s,r)=>s+(r[textCol]||"").length,0)/Math.min(500,dataset.length))+" chars" },
                    { k:"Missing Text Rows", v:String(dataset.filter(r=>!r[textCol]?.trim()).length) },
                    { k:"Status", v:"Ready for Training ✓" },
                  ].map(({ k, v }) => (
                    <div key={k} className="flex items-center justify-between py-2 border-b" style={{ borderColor:"rgba(56,189,248,0.06)" }}>
                      <span className="text-sm" style={{ color:"#64748b" }}>{k}</span>
                      <span className="text-sm font-mono font-medium" style={{ color:v.includes("Ready")?"#22c55e":"#94a3b8" }}>{v}</span>
                    </div>
                  ))}
                </Card>
              </div>
              <Card>
                <h3 className="font-bold text-white mb-4">Class Distribution</h3>
                <div className="flex flex-col items-center">
                  <svg viewBox="0 0 120 120" width="120" height="120">
                    <circle cx="60" cy="60" r="42" fill="none" stroke="rgba(239,68,68,0.25)" strokeWidth="16" />
                    <circle cx="60" cy="60" r="42" fill="none" stroke="#22c55e" strokeWidth="16"
                      strokeDasharray={`${(realPct/100)*circ} ${circ}`} strokeLinecap="round" transform="rotate(-90 60 60)" />
                    <text x="60" y="57" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold" fontFamily="JetBrains Mono">{realPct}%</text>
                    <text x="60" y="70" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="Inter">Real</text>
                  </svg>
                  <div className="flex flex-col gap-2 mt-3 w-full text-xs">
                    <div className="flex justify-between"><span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background:"#22c55e" }} />Real ({lmap.realLabel})</span><span className="font-mono" style={{ color:"#22c55e" }}>{realCount.toLocaleString()} ({realPct}%)</span></div>
                    <div className="flex justify-between"><span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background:"#ef4444" }} />Fake ({lmap.fakeLabel})</span><span className="font-mono" style={{ color:"#ef4444" }}>{fakeCount.toLocaleString()} ({100-realPct}%)</span></div>
                  </div>
                </div>
              </Card>
            </div>

            <Card>
              <h3 className="font-bold text-white mb-4">Dataset Preview <span className="text-xs font-normal ml-2" style={{ color:"#64748b" }}>First 8 rows — actual data</span></h3>
              <div className="overflow-auto rounded-lg" style={{ border:"1px solid rgba(56,189,248,0.08)" }}>
                <table className="w-full text-sm">
                  <thead><tr style={{ background:"rgba(56,189,248,0.04)" }}>
                    {["#","Text (preview)","Raw Label","Normalised"].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-mono font-semibold" style={{ color:"#64748b", borderBottom:"1px solid rgba(56,189,248,0.08)" }}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {dataset.slice(0,8).map((r, i) => {
                      const raw = r[labelCol]?.trim() ?? "";
                      const norm = normalizeLabel(raw, lmap);
                      return (
                        <tr key={i} style={{ borderBottom:"1px solid rgba(56,189,248,0.05)" }}>
                          <td className="px-4 py-3 font-mono text-xs" style={{ color:"#64748b" }}>{i+1}</td>
                          <td className="px-4 py-3 text-xs text-white" style={{ maxWidth:340 }}>{(r[textCol]||"").slice(0,110)}{(r[textCol]||"").length>110?"…":""}</td>
                          <td className="px-4 py-3 font-mono text-xs" style={{ color:"#94a3b8" }}>{raw}</td>
                          <td className="px-4 py-3"><Badge label={norm} fake={norm==="FAKE"} /></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

// ─── PREPROCESSING ────────────────────────────────────────────────────────────

function PreprocessingScreen() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState<ReturnType<typeof preprocess>|null>(null);
  const run = () => { if (input.trim()) setResult(preprocess(input)); };
  const tfidf = result
    ? [...new Map(result.stemmed.map(t => [t, result.stemmed.filter(x=>x===t).length/result.stemmed.length])).entries()].sort((a,b)=>b[1]-a[1]).slice(0,8)
    : [];
  const maxW = tfidf[0]?.[1] || 1;
  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="max-w-5xl mx-auto flex flex-col gap-5">
        <Card>
          <h3 className="font-bold text-white mb-3">Enter News Text</h3>
          <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Paste any news article or headline…" rows={5}
            className="w-full rounded-lg px-4 py-3 text-sm resize-none outline-none"
            style={{ background:"rgba(56,189,248,0.04)", border:"1px solid rgba(56,189,248,0.12)", color:"#e8edf5", fontFamily:"Inter,sans-serif", caretColor:"#38bdf8" }} />
          <div className="flex justify-between mt-3">
            <span className="text-xs font-mono" style={{ color:"#64748b" }}>{input.length} chars</span>
            <div className="flex gap-2">
              <Btn variant="ghost" onClick={() => { setInput(""); setResult(null); }}>Clear</Btn>
              <Btn onClick={run} disabled={!input.trim()}>Process Text</Btn>
            </div>
          </div>
        </Card>
        <Card>
          <h3 className="font-bold text-white mb-4">Processing Pipeline</h3>
          <div className="flex items-center gap-1 flex-wrap">
            {["Raw Text","Lowercase","Remove Noise","Remove Stopwords","Tokenize","Stem (Porter)","TF-IDF Ready"].map((lbl,i,arr) => (
              <div key={lbl} className="flex items-center gap-1">
                <div className="flex flex-col items-center gap-1.5">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background:result?"rgba(56,189,248,0.12)":"rgba(56,189,248,0.03)", border:`1px solid ${result?"rgba(56,189,248,0.3)":"rgba(56,189,248,0.08)"}` }}>
                    {result?<span style={{ color:"#38bdf8" }}><I.Check /></span>:<div className="w-2 h-2 rounded-full" style={{ background:"rgba(56,189,248,0.2)" }} />}
                  </div>
                  <span className="text-xs text-center" style={{ color:result?"#94a3b8":"#64748b", fontSize:9, maxWidth:72 }}>{lbl}</span>
                </div>
                {i<arr.length-1 && <span className="mb-5" style={{ color:result?"rgba(56,189,248,0.4)":"rgba(56,189,248,0.1)" }}><I.Chevron /></span>}
              </div>
            ))}
          </div>
        </Card>
        {result && (
          <div className="animate-fade-in flex flex-col gap-5">
            <div className="grid grid-cols-2 gap-5">
              <Card><h3 className="text-sm font-semibold mb-2" style={{ color:"#94a3b8" }}>Original Text</h3><div className="p-3 rounded-lg text-xs leading-relaxed font-mono" style={{ background:"rgba(56,189,248,0.03)", border:"1px solid rgba(56,189,248,0.06)", color:"#94a3b8" }}>{input}</div></Card>
              <Card><h3 className="text-sm font-semibold mb-2" style={{ color:"#38bdf8" }}>After Noise Removal</h3><div className="p-3 rounded-lg text-xs leading-relaxed font-mono" style={{ background:"rgba(56,189,248,0.05)", border:"1px solid rgba(56,189,248,0.15)", color:"#38bdf8" }}>{result.noNoise}</div></Card>
            </div>
            <div className="grid grid-cols-2 gap-5">
              <Card><h3 className="text-sm font-semibold mb-2" style={{ color:"#06b6d4" }}>After Stopword Removal</h3><div className="p-3 rounded-lg text-xs leading-relaxed font-mono" style={{ background:"rgba(6,182,212,0.05)", border:"1px solid rgba(6,182,212,0.12)", color:"#06b6d4" }}>{result.noStopwords}</div></Card>
              <Card><h3 className="text-sm font-semibold mb-2" style={{ color:"#34d399" }}>After Stemming (Final)</h3><div className="p-3 rounded-lg text-xs leading-relaxed font-mono" style={{ background:"rgba(34,211,153,0.05)", border:"1px solid rgba(34,211,153,0.12)", color:"#34d399" }}>{result.stemmed.join(" ")}</div></Card>
            </div>
            <div className="grid grid-cols-2 gap-5">
              <Card>
                <h3 className="font-semibold text-white mb-3">Tokens <span className="text-xs ml-1" style={{ color:"#64748b" }}>{result.tokens.length} after stopword removal</span></h3>
                <div className="flex flex-wrap gap-2 max-h-32 overflow-auto">
                  {result.tokens.map((t,i)=><span key={i} className="px-2.5 py-1 rounded-lg text-xs font-mono" style={{ background:"rgba(56,189,248,0.08)", color:"#38bdf8", border:"1px solid rgba(56,189,248,0.15)" }}>{t}</span>)}
                </div>
              </Card>
              <Card>
                <h3 className="font-semibold text-white mb-3">TF-IDF Weights</h3>
                <div className="flex flex-col gap-2">
                  {tfidf.map(([word,w])=>(
                    <div key={word} className="flex items-center gap-3">
                      <span className="text-xs font-mono w-24 text-right shrink-0" style={{ color:"#64748b" }}>{word}</span>
                      <div className="flex-1 h-2 rounded-full" style={{ background:"rgba(56,189,248,0.08)" }}>
                        <div className="h-2 rounded-full" style={{ width:`${(w/maxW)*100}%`, background:"linear-gradient(90deg,#38bdf8,#06b6d4)" }} />
                      </div>
                      <span className="text-xs font-mono w-12 shrink-0" style={{ color:"#38bdf8" }}>{w.toFixed(3)}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
            <div className="rounded-xl p-4 flex items-center gap-3" style={{ background:"rgba(34,197,94,0.06)", border:"1px solid rgba(34,197,94,0.2)" }}>
              <span style={{ color:"#22c55e" }}><I.Check /></span>
              <span className="text-sm text-white">Complete · {input.length} chars → {result.tokens.length} tokens → {result.stemmed.length} stems</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── TRAINING ─────────────────────────────────────────────────────────────────

interface AlgoProgress { pct: number; done: boolean; log: string[] }

function TrainingScreen() {
  const { dataset, textCol, labelCol, lmap, vocab, models, bestModel, setVocab, addModel, clearModels } = useApp();
  const [prog, setProg] = useState<Record<string, AlgoProgress>>({});
  const [running, setRunning] = useState(false);
  const [split, setSplit] = useState(0.8);
  const stopped = useRef(false);

  const upd = (algo: string, patch: Partial<AlgoProgress>) =>
    setProg(p => {
      const cur: AlgoProgress = p[algo] ?? { pct:0, done:false, log:[] };
      return { ...p, [algo]: { ...cur, ...patch } };
    });
  const log = (algo: string, msg: string) =>
    setProg(p => {
      const cur: AlgoProgress = p[algo] ?? { pct:0, done:false, log:[] };
      return { ...p, [algo]: { ...cur, log:[...cur.log, msg] } };
    });

  const trainAll = useCallback(async () => {
    if (!dataset.length || !lmap) return;
    setRunning(true); stopped.current = false; clearModels(); setProg({});
    const tick = () => new Promise<void>(r => setTimeout(r, 0));

    // Step 1 — preprocess in chunks (keeps UI responsive for 20K rows)
    log("Naive Bayes","Preprocessing text (chunked for large datasets)…");
    await tick();
    const CHUNK = 500;
    const allDocs: string[][] = [];
    const allLabels: string[] = [];
    for (let i = 0; i < dataset.length; i += CHUNK) {
      for (const r of dataset.slice(i, i + CHUNK)) {
        allDocs.push(preprocess(r[textCol] || "").stemmed);
        allLabels.push(normalizeLabel((r[labelCol] || "").trim(), lmap));
      }
      upd("Naive Bayes", { pct: Math.round((i / dataset.length) * 15) });
      await tick();
      if (stopped.current) { setRunning(false); return; }
    }

    // Step 2 — train/test split
    const si = Math.floor(allDocs.length * split);
    const trDocs = allDocs.slice(0, si), trLabels = allLabels.slice(0, si);
    const teDocs = allDocs.slice(si),   teLabels = allLabels.slice(si);
    log("Naive Bayes", `Train: ${trDocs.length} · Test: ${teDocs.length} · Classes: FAKE / REAL`);
    await tick();

    // Step 3 — build shared vocabulary
    const maxF = dataset.length > 10000 ? 7000 : 5000;
    const minDF = dataset.length > 10000 ? 3 : 2;
    const v = buildVocab(trDocs, maxF, minDF);
    setVocab(v);
    log("Naive Bayes", `Vocabulary: ${v.terms.length} features · minDF=${minDF}`);
    upd("Naive Bayes", { pct: 20 }); await tick();

    // ── NAIVE BAYES ─────────────────────────────────────────────────────────
    log("Naive Bayes","Training Multinomial Naive Bayes…"); await tick();
    const nbM = trainNaiveBayes(trDocs, trLabels, v);
    upd("Naive Bayes", { pct:80 });
    log("Naive Bayes","Evaluating on test set…"); await tick();
    const nbE = evaluate(teDocs, teLabels, nbM);
    log("Naive Bayes", `Accuracy: ${pct(nbE.accuracy)} | F1-FAKE: ${pct(nbE.f1["FAKE"]??0)}`);
    log("Naive Bayes","✓ Done");
    upd("Naive Bayes", { pct:100, done:true });
    addModel({ algo:"Naive Bayes", model:nbM, eval:nbE }); await tick();
    if (stopped.current) { setRunning(false); return; }

    // ── LOGISTIC REGRESSION ─────────────────────────────────────────────────
    log("Logistic Regression","Training with mini-batch SGD…"); await tick();
    const lrM = trainLogisticRegression(trDocs, trLabels, v, "FAKE",
      dataset.length > 10000 ? 6 : 8, 0.2, 1e-4, 128,
      p => upd("Logistic Regression", { pct: Math.round(p * 0.85) }),
    );
    upd("Logistic Regression", { pct:90 });
    log("Logistic Regression","Evaluating…"); await tick();
    const lrE = evaluate(teDocs, teLabels, lrM);
    log("Logistic Regression", `Accuracy: ${pct(lrE.accuracy)} | F1-FAKE: ${pct(lrE.f1["FAKE"]??0)}`);
    log("Logistic Regression","✓ Done");
    upd("Logistic Regression", { pct:100, done:true });
    addModel({ algo:"Logistic Regression", model:lrM, eval:lrE }); await tick();
    if (stopped.current) { setRunning(false); return; }

    // ── SVM ─────────────────────────────────────────────────────────────────
    log("SVM","Training linear SVM (Pegasos)…"); await tick();
    const svmM = trainSVM(trDocs, trLabels, v, "FAKE",
      dataset.length > 10000 ? 8 : 10, 1.5, 64,
      p => upd("SVM", { pct: Math.round(p * 0.85) }),
    );
    upd("SVM", { pct:90 });
    log("SVM","Evaluating…"); await tick();
    const svmE = evaluate(teDocs, teLabels, svmM);
    log("SVM", `Accuracy: ${pct(svmE.accuracy)} | F1-FAKE: ${pct(svmE.f1["FAKE"]??0)}`);
    log("SVM","✓ Done");
    upd("SVM", { pct:100, done:true });
    addModel({ algo:"SVM", model:svmM, eval:svmE }); await tick();

    setRunning(false);
  }, [dataset, textCol, labelCol, lmap, split, setVocab, addModel, clearModels]);

  const algoColors: Record<string, string> = { "Naive Bayes":"#38bdf8", "Logistic Regression":"#06b6d4", "SVM":"#22c55e" };
  const algos: AlgoName[] = ["Naive Bayes","Logistic Regression","SVM"];
  const classes = ["FAKE","REAL"];

  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="max-w-5xl mx-auto flex flex-col gap-5">
        <Card>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background:dataset.length?"rgba(34,197,94,0.1)":"rgba(239,68,68,0.1)", border:`1px solid ${dataset.length?"rgba(34,197,94,0.2)":"rgba(239,68,68,0.2)"}` }}>
              <span style={{ color:dataset.length?"#22c55e":"#ef4444" }}>{dataset.length?<I.Check/>:<I.Warn/>}</span>
            </div>
            <div className="flex-1">
              <div className="font-bold text-white text-sm">{dataset.length?`Dataset Ready — ${dataset.length.toLocaleString()} records`:"No Dataset Loaded"}</div>
              {lmap && <div className="text-xs mt-0.5" style={{ color:"#64748b" }}>FAKE="{lmap.fakeLabel}" · REAL="{lmap.realLabel}" · Text: "{textCol}" · Label: "{labelCol}"</div>}
              {!dataset.length && <div className="text-xs mt-0.5" style={{ color:"#64748b" }}>Upload a CSV on the Dataset screen first.</div>}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs" style={{ color:"#64748b" }}>Split:</span>
              <select value={split} onChange={e=>setSplit(+e.target.value)} className="text-xs rounded-lg px-2 py-1.5 font-mono outline-none"
                style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.15)", color:"#94a3b8" }}>
                <option value={0.7}>70/30</option><option value={0.8}>80/20</option><option value={0.9}>90/10</option>
              </select>
            </div>
          </div>
        </Card>

        <div className="flex items-center gap-3">
          <Btn onClick={trainAll} disabled={!dataset.length||running}>
            <I.Brain /> {running?"Training…": models.length?"Retrain All Models":"Train All Models (NB + LR + SVM)"}
          </Btn>
          {running && <Btn variant="danger" onClick={()=>{stopped.current=true; setRunning(false);}}>Stop</Btn>}
          {models.length>0&&!running && (
            <div className="text-xs px-3 py-2 rounded-lg" style={{ background:"rgba(34,197,94,0.08)", color:"#22c55e", border:"1px solid rgba(34,197,94,0.2)" }}>
              ✓ {models.length} models trained · Vocab: {vocab?.terms.length.toLocaleString()??0} features
            </div>
          )}
        </div>

        {/* Per-algo progress */}
        {Object.keys(prog).length > 0 && (
          <div className="grid grid-cols-3 gap-4">
            {algos.map(algo => {
              const p = prog[algo] ?? { pct:0, done:false, log:[] };
              const c = algoColors[algo];
              return (
                <Card key={algo}>
                  <div className="flex justify-between mb-2"><span className="text-xs font-bold" style={{ color:c }}>{algo}</span><span className="text-xs font-mono" style={{ color:c }}>{p.pct}%</span></div>
                  <div className="h-1.5 rounded-full mb-3" style={{ background:"rgba(56,189,248,0.08)" }}>
                    <div className="h-1.5 rounded-full transition-all" style={{ width:`${p.pct}%`, background:c }} />
                  </div>
                  <div className="text-xs font-mono flex flex-col gap-0.5 max-h-24 overflow-auto" style={{ color:"#64748b" }}>
                    {p.log.map((l,i)=><div key={i} style={{ color:l.includes("✓")?"#22c55e":l.includes("Accuracy")?"#38bdf8":"#64748b" }}>› {l}</div>)}
                    {running&&!p.done&&p.pct>0&&<div className="animate-pulse-glow" style={{ color:c }}>›_</div>}
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {/* Results */}
        {models.length > 0 && (
          <div className="animate-fade-in flex flex-col gap-5">
            <Card>
              <h3 className="font-bold text-white mb-4">Model Performance Comparison</h3>
              <div className="rounded-lg overflow-hidden" style={{ border:"1px solid rgba(56,189,248,0.08)" }}>
                <table className="w-full text-sm">
                  <thead><tr style={{ background:"rgba(56,189,248,0.04)" }}>
                    {["Algorithm","Accuracy","F1 (FAKE)","F1 (REAL)","Precision","Recall","Test Size"].map(h=>(
                      <th key={h} className="text-left px-4 py-3 text-xs font-mono font-semibold" style={{ color:"#64748b", borderBottom:"1px solid rgba(56,189,248,0.08)" }}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {models.map((m,i)=>{
                      const best = m===bestModel;
                      const c = algoColors[m.algo];
                      return (
                        <tr key={m.algo} style={{ borderBottom:i<models.length-1?"1px solid rgba(56,189,248,0.05)":"none", background:best?"rgba(34,197,94,0.03)":"transparent" }}>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full" style={{ background:c }} />
                              <span className="text-sm font-medium text-white">{m.algo}</span>
                              {best&&<span className="text-xs px-1.5 py-0.5 rounded ml-1" style={{ background:"rgba(34,197,94,0.15)", color:"#22c55e" }}>🏆 Best</span>}
                            </div>
                          </td>
                          <td className="px-4 py-3 font-mono font-bold" style={{ color:best?"#22c55e":c }}>{pct(m.eval.accuracy)}</td>
                          <td className="px-4 py-3 font-mono" style={{ color:"#ef4444" }}>{pct(m.eval.f1["FAKE"]??0)}</td>
                          <td className="px-4 py-3 font-mono" style={{ color:"#22c55e" }}>{pct(m.eval.f1["REAL"]??0)}</td>
                          <td className="px-4 py-3 font-mono text-xs" style={{ color:"#64748b" }}>{pct(m.eval.precision["FAKE"]??0)}</td>
                          <td className="px-4 py-3 font-mono text-xs" style={{ color:"#64748b" }}>{pct(m.eval.recall["FAKE"]??0)}</td>
                          <td className="px-4 py-3 font-mono text-xs" style={{ color:"#64748b" }}>{m.eval.samples.toLocaleString()}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>

            <div className="grid grid-cols-2 gap-5">
              {bestModel && (
                <Card style={{ border:"1px solid rgba(34,197,94,0.2)", background:"rgba(34,197,94,0.02)" }}>
                  <div className="flex items-center gap-2 mb-3"><I.Award /><h3 className="font-bold text-white">Best Performing Model</h3></div>
                  <div className="text-2xl font-black mb-1" style={{ color:"#22c55e" }}>{bestModel.algo}</div>
                  <div className="text-4xl font-black font-mono mb-2" style={{ color:"#22c55e" }}>{pct(bestModel.eval.accuracy)}</div>
                  <div className="text-xs mb-3" style={{ color:"#64748b" }}>Automatically selected by highest test accuracy. Used as default in Fraud Detection.</div>
                  <div className="grid grid-cols-2 gap-2">
                    {classes.map(cls=>(
                      <div key={cls} className="rounded-lg p-2.5" style={{ background:cls==="FAKE"?"rgba(239,68,68,0.08)":"rgba(34,197,94,0.08)" }}>
                        <div className="text-xs mb-0.5" style={{ color:"#64748b" }}>F1 ({cls})</div>
                        <div className="font-mono font-bold" style={{ color:cls==="FAKE"?"#ef4444":"#22c55e" }}>{pct(bestModel.eval.f1[cls]??0)}</div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}

              {bestModel && (
                <Card>
                  <h3 className="font-bold text-white mb-2">Confusion Matrix <span className="text-xs font-normal ml-1" style={{ color:"#64748b" }}>{bestModel.algo}</span></h3>
                  <div className="text-xs mb-3 font-mono" style={{ color:"#64748b" }}>Rows = Actual · Columns = Predicted</div>
                  <table>
                    <thead><tr>
                      <th className="px-3 py-2 text-xs font-mono" style={{ color:"#64748b" }}>A\P</th>
                      {classes.map(c=><th key={c} className="px-3 py-2 text-xs font-mono" style={{ color:c==="FAKE"?"#ef4444":"#22c55e" }}>{c}</th>)}
                    </tr></thead>
                    <tbody>
                      {classes.map(actual=>(
                        <tr key={actual}>
                          <td className="px-3 py-2 text-xs font-mono" style={{ color:actual==="FAKE"?"#ef4444":"#22c55e" }}>{actual}</td>
                          {classes.map(pred=>{
                            const v = bestModel.eval.confusionMatrix[actual]?.[pred]??0;
                            const diag = actual===pred;
                            return (
                              <td key={pred} className="px-3 py-2">
                                <div className="w-20 h-12 rounded-lg flex flex-col items-center justify-center font-mono" style={{ background:diag?"rgba(34,197,94,0.1)":"rgba(239,68,68,0.07)", border:`1px solid ${diag?"rgba(34,197,94,0.25)":"rgba(239,68,68,0.15)"}` }}>
                                  <div className="font-bold text-base" style={{ color:diag?"#22c55e":"#ef4444" }}>{v.toLocaleString()}</div>
                                  <div className="text-xs" style={{ color:"#64748b" }}>{diag?(actual==="FAKE"?"TP":"TN"):(actual==="FAKE"?"FN":"FP")}</div>
                                </div>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── DETECTION ────────────────────────────────────────────────────────────────

function DetectionScreen({ onNav }: { onNav:(s:Screen)=>void }) {
  const { bestModel, models, addPrediction } = useApp();
  const [article, setArticle] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<PredictResult|null>(null);
  const [usedAlgo, setUsedAlgo] = useState<AlgoName|"">("");
  const [step, setStep] = useState(0);
  const [pick, setPick] = useState<AlgoName|"best">("best");

  const steps = ["Input","Preprocess","TF-IDF","Model","Result"];
  const activeEntry = pick==="best" ? bestModel : models.find(m=>m.algo===pick)??bestModel;

  const analyze = async () => {
    if (!article.trim()||!activeEntry) return;
    setResult(null); setAnalyzing(true); setStep(0);
    for (let s=1; s<=steps.length; s++) { await new Promise(r=>setTimeout(r,380)); setStep(s); }
    const { stemmed } = preprocess(article);
    const pred = predict(stemmed, activeEntry.model);
    setResult(pred); setUsedAlgo(activeEntry.algo); setAnalyzing(false);
    addPrediction({ id:Date.now(), article:article.slice(0,120), processedText:stemmed.join(" ").slice(0,200), result:pred, algo:activeEntry.algo, date:new Date().toLocaleString() });
  };

  const fake = result ? isFake(result.label) : false;
  const rc = fake?"#ef4444":"#22c55e";

  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="max-w-5xl mx-auto flex flex-col gap-5">
        {!bestModel && (
          <div className="rounded-xl p-4 flex items-center gap-3" style={{ background:"rgba(251,191,36,0.06)", border:"1px solid rgba(251,191,36,0.2)" }}>
            <I.Warn /><span className="text-sm" style={{ color:"#fbbf24" }}>No trained model. <button onClick={()=>onNav("training")} className="underline cursor-pointer" style={{ color:"#fbbf24" }}>Go to Model Training →</button></span>
          </div>
        )}

        {models.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs" style={{ color:"#64748b" }}>Use model:</span>
            {(["best","Naive Bayes","Logistic Regression","SVM"] as const).map(a=>(
              <button key={a} onClick={()=>setPick(a)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer"
                style={{ background:pick===a?"rgba(56,189,248,0.12)":"transparent", color:pick===a?"#38bdf8":"#64748b", border:`1px solid ${pick===a?"rgba(56,189,248,0.2)":"rgba(56,189,248,0.08)"}` }}>
                {a==="best" ? `Best (${bestModel?.algo??"—"})` : a}
                {a!=="best" && (() => { const m=models.find(x=>x.algo===a); return m?<span className="ml-1 font-mono" style={{ color:"#64748b", fontSize:9 }}>{pct(m.eval.accuracy)}</span>:null; })()}
              </button>
            ))}
          </div>
        )}

        <Card>
          <h3 className="font-bold text-white mb-3">Enter or Paste News Article</h3>
          <textarea value={article} onChange={e=>setArticle(e.target.value)} placeholder="Paste the complete news article or headline here…" rows={7}
            className="w-full rounded-lg px-4 py-3 text-sm resize-none outline-none"
            style={{ background:"rgba(56,189,248,0.04)", border:"1px solid rgba(56,189,248,0.12)", color:"#e8edf5", fontFamily:"Inter,sans-serif", caretColor:"#38bdf8" }} />
          <div className="flex justify-between mt-3">
            <span className="text-xs font-mono" style={{ color:"#64748b" }}>{article.length} chars</span>
            <div className="flex gap-2">
              <Btn variant="ghost" onClick={()=>{setArticle("");setResult(null);setStep(0);}}>Clear</Btn>
              <Btn onClick={analyze} disabled={!article.trim()||!activeEntry||analyzing}><I.Search />{analyzing?"Analyzing…":"Analyze News"}</Btn>
            </div>
          </div>
        </Card>

        {(analyzing||result) && (
          <Card>
            <h3 className="font-semibold text-white mb-4">Pipeline — {usedAlgo||activeEntry?.algo}</h3>
            <div className="flex items-center gap-3 flex-wrap">
              {steps.map((s,i)=>(
                <div key={s} className="flex items-center gap-3">
                  <div className="flex flex-col items-center gap-1.5">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center transition-all"
                      style={{ background:i<step?"rgba(56,189,248,0.15)":"rgba(56,189,248,0.04)", border:`1px solid ${i<step?"rgba(56,189,248,0.3)":"rgba(56,189,248,0.08)"}` }}>
                      {i<step?<span style={{ color:"#38bdf8" }}><I.Check /></span>:i===step&&analyzing?<div className="w-3 h-3 rounded-full animate-pulse-glow" style={{ background:"#38bdf8" }} />:<div className="w-2 h-2 rounded-full" style={{ background:"rgba(56,189,248,0.2)" }} />}
                    </div>
                    <span className="text-xs" style={{ color:i<step?"#94a3b8":"#64748b" }}>{s}</span>
                  </div>
                  {i<steps.length-1&&<span className="mb-5" style={{ color:i<step?"rgba(56,189,248,0.5)":"rgba(56,189,248,0.1)" }}><I.Arrow /></span>}
                </div>
              ))}
            </div>
          </Card>
        )}

        {result && (
          <div className="animate-fade-in grid grid-cols-2 gap-5">
            <div className="rounded-xl p-6" style={{ background:`linear-gradient(135deg,${rc}10,${rc}04)`, border:`1px solid ${rc}35`, boxShadow:`0 0 30px ${rc}12` }}>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ background:`${rc}20`, border:`1px solid ${rc}40` }}>
                  <span style={{ color:rc, transform:"scale(1.5)" }}>{fake?<I.Warn/>:<I.Check/>}</span>
                </div>
                <div>
                  <div className="text-2xl font-black mb-1" style={{ color:rc }}>{fake?"⚠ FAKE NEWS":"✓ REAL NEWS"}</div>
                  <Badge label={result.label} fake={fake} />
                  <div className="text-xs mt-1 font-mono" style={{ color:"#64748b" }}>via {usedAlgo}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="rounded-xl p-4" style={{ background:"rgba(0,0,0,0.25)" }}>
                  <div className="text-xs mb-1" style={{ color:"#64748b" }}>Confidence</div>
                  <div className="text-3xl font-black font-mono" style={{ color:rc }}>{result.confidence}%</div>
                </div>
                <div className="rounded-xl p-4" style={{ background:"rgba(0,0,0,0.25)" }}>
                  <div className="text-xs mb-1" style={{ color:"#64748b" }}>Risk Level</div>
                  <div className="text-xl font-bold" style={{ color:rc }}>{riskLevel(result.confidence,fake)}</div>
                </div>
              </div>
              {Object.entries(result.scores).map(([cls,prob])=>(
                <div key={cls} className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-mono w-16 shrink-0" style={{ color:"#64748b" }}>{cls}</span>
                  <div className="flex-1 h-1.5 rounded-full" style={{ background:"rgba(255,255,255,0.07)" }}>
                    <div className="h-1.5 rounded-full" style={{ width:`${prob*100}%`, background:isFake(cls)?"#ef4444":"#22c55e" }} />
                  </div>
                  <span className="text-xs font-mono w-10 text-right" style={{ color:"#94a3b8" }}>{(prob*100).toFixed(1)}%</span>
                </div>
              ))}
            </div>
            <div className="flex flex-col gap-4">
              <Card>
                <h3 className="font-semibold text-white mb-2">Top Discriminative Features</h3>
                <p className="text-xs mb-3" style={{ color:"#64748b" }}>Words with highest influence on this prediction:</p>
                <div className="flex flex-wrap gap-2">
                  {result.topFeatures.map(({word})=>(
                    <span key={word} className="px-2.5 py-1 rounded-lg text-xs font-mono" style={{ background:`${rc}10`, color:rc, border:`1px solid ${rc}22` }}>{word}</span>
                  ))}
                </div>
              </Card>
              <Card>
                <h3 className="font-semibold text-white mb-1">Model Used</h3>
                <div className="text-sm font-mono" style={{ color:"#38bdf8" }}>{usedAlgo}</div>
                {(() => { const m=models.find(x=>x.algo===usedAlgo); return m?<div className="text-xs mt-1" style={{ color:"#64748b" }}>Test accuracy: {pct(m.eval.accuracy)} · {m.eval.samples.toLocaleString()} test samples</div>:null; })()}
              </Card>
              <div className="rounded-xl p-3 text-xs" style={{ background:"rgba(251,191,36,0.04)", border:"1px solid rgba(251,191,36,0.12)", color:"#64748b" }}>
                ⚠ Predictions are generated by the trained ML model and should be independently verified.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────

function DashboardScreen() {
  const { dataset, labelCol, lmap, models, bestModel, predictions } = useApp();
  const fakeDataset = lmap ? dataset.filter(r=>r[labelCol]?.trim()===lmap.fakeLabel).length : 0;
  const realDataset = dataset.length - fakeDataset;
  const predFake = predictions.filter(p=>isFake(p.result.label)).length;
  const predReal = predictions.length - predFake;
  const realPct  = predictions.length ? Math.round((predReal/predictions.length)*100) : 0;
  const circ = 2*Math.PI*42;
  const ac: Record<string,string> = { "Naive Bayes":"#38bdf8", "Logistic Regression":"#06b6d4", "SVM":"#22c55e" };

  return (
    <div className="flex-1 overflow-auto p-8">
      <div className="max-w-6xl mx-auto flex flex-col gap-5">
        <div className="grid grid-cols-6 gap-4">
          <KPI label="News Analyzed" value={predictions.length.toString()} icon={<I.Search />} />
          <KPI label="Predicted Real" value={predReal.toString()} color="#22c55e" icon={<I.Check />} />
          <KPI label="Predicted Fake" value={predFake.toString()} color="#ef4444" icon={<I.Warn />} />
          <KPI label="Best Model" value={bestModel?.algo==="SVM"?"SVM":bestModel?.algo??"—"} color="#22c55e" icon={<I.Award />} />
          <KPI label="Best Accuracy" value={bestModel?pct(bestModel.eval.accuracy):"—"} color="#818cf8" icon={<I.Trend />} />
          <KPI label="Dataset Size" value={dataset.length?dataset.length.toLocaleString():"—"} color="#06b6d4" icon={<I.Database />} />
        </div>

        <div className="grid grid-cols-3 gap-5">
          <Card>
            <h3 className="font-bold text-white mb-4">Prediction Results</h3>
            <div className="flex flex-col items-center">
              <svg viewBox="0 0 120 120" width="120" height="120">
                <circle cx="60" cy="60" r="42" fill="none" stroke="rgba(239,68,68,0.2)" strokeWidth="16" />
                {predictions.length>0&&<circle cx="60" cy="60" r="42" fill="none" stroke="#22c55e" strokeWidth="16" strokeDasharray={`${(realPct/100)*circ} ${circ}`} strokeLinecap="round" transform="rotate(-90 60 60)" />}
                <text x="60" y="57" textAnchor="middle" fill="white" fontSize="13" fontWeight="bold" fontFamily="JetBrains Mono">{predictions.length?realPct+"%":"—"}</text>
                <text x="60" y="70" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="Inter">Real</text>
              </svg>
              <div className="flex flex-col gap-2 mt-2 w-full text-xs">
                <div className="flex justify-between"><span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background:"#22c55e" }} />Real</span><span className="font-mono" style={{ color:"#22c55e" }}>{predReal}</span></div>
                <div className="flex justify-between"><span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background:"#ef4444" }} />Fake</span><span className="font-mono" style={{ color:"#ef4444" }}>{predFake}</span></div>
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="font-bold text-white mb-4">Model Accuracy Comparison</h3>
            {models.length===0
              ? <div className="text-xs" style={{ color:"#64748b" }}>Train models to see comparison.</div>
              : models.map(m=>(
                <div key={m.algo} className="mb-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span style={{ color:"#64748b" }}>{m.algo}{m===bestModel?" 🏆":""}</span>
                    <span className="font-mono font-bold" style={{ color:ac[m.algo] }}>{pct(m.eval.accuracy)}</span>
                  </div>
                  <div className="h-3 rounded-full" style={{ background:"rgba(56,189,248,0.06)" }}>
                    <div className="h-3 rounded-full" style={{ width:`${m.eval.accuracy*100}%`, background:ac[m.algo] }} />
                  </div>
                </div>
              ))
            }
          </Card>

          <Card>
            <h3 className="font-bold text-white mb-4">Dataset Distribution</h3>
            {dataset.length>0
              ?[{ label:"Real", count:realDataset, color:"#22c55e" },{ label:"Fake", count:fakeDataset, color:"#ef4444" }].map(({label,count,color})=>(
                <div key={label} className="mb-3">
                  <div className="flex justify-between text-xs mb-1"><span style={{ color:"#64748b" }}>{label}</span><span className="font-mono" style={{ color }}>{count.toLocaleString()} ({Math.round(count/dataset.length*100)}%)</span></div>
                  <div className="h-3 rounded-full" style={{ background:"rgba(56,189,248,0.06)" }}><div className="h-3 rounded-full" style={{ width:`${(count/dataset.length)*100}%`, background:color }} /></div>
                </div>
              ))
              :<div className="text-xs" style={{ color:"#64748b" }}>Upload a dataset.</div>
            }
          </Card>
        </div>

        <Card>
          <h3 className="font-bold text-white mb-4">Recent Predictions</h3>
          {predictions.length===0
            ?<div className="text-sm text-center py-8" style={{ color:"#64748b" }}>No predictions yet.</div>
            :(
              <div className="rounded-lg overflow-hidden" style={{ border:"1px solid rgba(56,189,248,0.08)" }}>
                <table className="w-full text-sm">
                  <thead><tr style={{ background:"rgba(56,189,248,0.04)" }}>
                    {["News Article","Prediction","Confidence","Algorithm","Date"].map(h=>(
                      <th key={h} className="text-left px-4 py-3 text-xs font-mono font-semibold" style={{ color:"#64748b", borderBottom:"1px solid rgba(56,189,248,0.08)" }}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {[...predictions].reverse().slice(0,8).map((p,i)=>{
                      const fake=isFake(p.result.label);
                      return (
                        <tr key={p.id} style={{ borderBottom:i<7?"1px solid rgba(56,189,248,0.05)":"none" }}>
                          <td className="px-4 py-3 text-xs text-white" style={{ maxWidth:280 }}>{p.article}{p.article.length>=120?"…":""}</td>
                          <td className="px-4 py-3"><Badge label={p.result.label} fake={fake} /></td>
                          <td className="px-4 py-3 font-mono font-bold text-xs" style={{ color:fake?"#ef4444":"#22c55e" }}>{p.result.confidence}%</td>
                          <td className="px-4 py-3 text-xs" style={{ color:ac[p.algo]??"#64748b" }}>{p.algo}</td>
                          <td className="px-4 py-3 text-xs" style={{ color:"#64748b" }}>{p.date}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )
          }
        </Card>
      </div>
    </div>
  );
}

// ─── RESULTS ──────────────────────────────────────────────────────────────────

function ResultsScreen({ onNav }: { onNav:(s:Screen)=>void }) {
  const { predictions, deletePrediction } = useApp();
  const [filter, setFilter] = useState<"all"|"real"|"fake">("all");
  const [search, setSearch] = useState("");
  const [sel, setSel] = useState<number|null>(null);

  const filtered = predictions.filter(p=>{
    const fake=isFake(p.result.label);
    if (filter==="real"&&fake) return false;
    if (filter==="fake"&&!fake) return false;
    if (search&&!p.article.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const selected = sel!==null ? predictions.find(p=>p.id===sel) : null;

  const exportCSV = () => {
    const h = "Article,Prediction,Confidence,Risk,Algorithm,Date";
    const rows = predictions.map(p=>`"${p.article.replace(/"/g,'""')}",${p.result.label},${p.result.confidence}%,${riskLevel(p.result.confidence,isFake(p.result.label))},${p.algo},${p.date}`);
    const blob = new Blob([[h,...rows].join("\n")],{type:"text/csv"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="predictions.csv";a.click();
  };

  return (
    <div className="flex-1 overflow-hidden flex flex-col">
      <div className="px-8 py-4 flex items-center gap-3 border-b" style={{ borderColor:"rgba(56,189,248,0.08)" }}>
        <div className="flex-1 relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color:"#64748b" }}><I.Search /></span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search articles…"
            className="w-full pl-9 pr-4 py-2 rounded-lg text-sm outline-none"
            style={{ background:"rgba(56,189,248,0.04)", border:"1px solid rgba(56,189,248,0.12)", color:"#e8edf5", fontFamily:"Inter,sans-serif" }} />
        </div>
        {(["all","real","fake"] as const).map(f=>(
          <button key={f} onClick={()=>setFilter(f)} className="px-3 py-2 rounded-lg text-xs font-semibold capitalize cursor-pointer"
            style={{ background:filter===f?"rgba(56,189,248,0.12)":"transparent", color:filter===f?"#38bdf8":"#64748b", border:`1px solid ${filter===f?"rgba(56,189,248,0.2)":"transparent"}` }}>
            {f}
          </button>
        ))}
        <Btn variant="secondary" onClick={exportCSV} disabled={!predictions.length}><I.Download /> Export CSV</Btn>
      </div>

      <div className="flex-1 overflow-hidden flex">
        <div className="flex-1 overflow-auto p-6">
          {filtered.length===0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4" style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.1)" }}><span style={{ color:"#38bdf8" }}><I.Search /></span></div>
              <div className="font-bold text-white mb-1">No predictions yet</div>
              <p className="text-sm mb-4" style={{ color:"#64748b" }}>Analyze your first article to see results here.</p>
              <Btn onClick={()=>onNav("detection")}>Analyze News <I.Arrow /></Btn>
            </div>
          ) : (
            <div className="rounded-xl overflow-hidden" style={{ border:"1px solid rgba(56,189,248,0.08)" }}>
              <table className="w-full text-sm">
                <thead><tr style={{ background:"rgba(56,189,248,0.04)" }}>
                  {["Article","Prediction","Confidence","Risk","Algorithm","Date",""].map((h,i)=>(
                    <th key={i} className="text-left px-4 py-3 text-xs font-mono font-semibold" style={{ color:"#64748b", borderBottom:"1px solid rgba(56,189,248,0.08)" }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {[...filtered].reverse().map((p,i)=>{
                    const fake=isFake(p.result.label);
                    const color=fake?"#ef4444":"#22c55e";
                    return (
                      <tr key={p.id} onClick={()=>setSel(sel===p.id?null:p.id)} className="cursor-pointer"
                        style={{ borderBottom:i<filtered.length-1?"1px solid rgba(56,189,248,0.05)":"none", background:sel===p.id?"rgba(56,189,248,0.05)":"transparent" }}>
                        <td className="px-4 py-3 text-xs text-white" style={{ maxWidth:200 }}>{p.article}{p.article.length>=120?"…":""}</td>
                        <td className="px-4 py-3"><Badge label={p.result.label} fake={fake} /></td>
                        <td className="px-4 py-3 font-mono font-bold" style={{ color }}>{p.result.confidence}%</td>
                        <td className="px-4 py-3 text-xs font-semibold" style={{ color }}>{riskLevel(p.result.confidence,fake)}</td>
                        <td className="px-4 py-3 text-xs" style={{ color:"#64748b" }}>{p.algo}</td>
                        <td className="px-4 py-3 text-xs" style={{ color:"#64748b" }}>{p.date}</td>
                        <td className="px-4 py-3"><button onClick={e=>{e.stopPropagation();deletePrediction(p.id);setSel(null);}} className="p-1.5 rounded cursor-pointer" style={{ color:"#64748b" }}><I.Trash /></button></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {selected && (() => {
          const fake=isFake(selected.result.label); const color=fake?"#ef4444":"#22c55e";
          return (
            <div className="w-72 shrink-0 border-l p-5 overflow-auto animate-fade-in" style={{ borderColor:"rgba(56,189,248,0.08)", background:"rgba(8,12,24,0.6)" }}>
              <div className="flex items-center justify-between mb-4"><h3 className="font-bold text-white text-sm">Detail</h3><button onClick={()=>setSel(null)} style={{ color:"#64748b" }}><I.X /></button></div>
              <div className="rounded-xl p-4 mb-4" style={{ background:`${color}10`, border:`1px solid ${color}30` }}>
                <div className="text-xl font-black mb-2" style={{ color }}>{fake?"⚠ FAKE":"✓ REAL"}</div>
                <Badge label={selected.result.label} fake={fake} />
              </div>
              {[{k:"Confidence",v:selected.result.confidence+"%"},{k:"Risk",v:riskLevel(selected.result.confidence,fake)},{k:"Algorithm",v:selected.algo},{k:"Date",v:selected.date}].map(({k,v})=>(
                <div key={k} className="mb-3"><div className="text-xs mb-0.5" style={{ color:"#64748b" }}>{k}</div><div className="font-mono font-semibold text-white text-sm">{v}</div></div>
              ))}
              <div className="mt-3">
                <div className="text-xs mb-2" style={{ color:"#64748b" }}>Processed Text</div>
                <div className="p-2.5 rounded-lg text-xs font-mono leading-relaxed" style={{ background:"rgba(56,189,248,0.04)", border:"1px solid rgba(56,189,248,0.08)", color:"#64748b" }}>{selected.processedText}…</div>
              </div>
              <div className="mt-3">
                <div className="text-xs mb-2" style={{ color:"#64748b" }}>Top Features</div>
                <div className="flex flex-wrap gap-1.5">
                  {selected.result.topFeatures.slice(0,10).map(({word})=>(
                    <span key={word} className="px-2 py-1 rounded text-xs font-mono" style={{ background:`${color}10`, color, border:`1px solid ${color}20` }}>{word}</span>
                  ))}
                </div>
              </div>
              <div className="flex gap-2 mt-5">
                <Btn variant="danger" className="flex-1 justify-center" onClick={()=>{deletePrediction(selected.id);setSel(null);}}><I.Trash /> Delete</Btn>
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [dataset, setDs] = useState<Row[]>([]);
  const [textCol, setTc] = useState("");
  const [labelCol, setLc] = useState("");
  const [lmap, setLmap] = useState<LabelMap|null>(null);
  const [vocab, setVocabState] = useState<Vocab|null>(null);
  const [models, setModels] = useState<ModelEntry[]>([]);
  const [predictions, setPreds] = useState<Prediction[]>([]);

  const bestModel = models.length > 0
    ? models.reduce((b,m) => m.eval.accuracy > b.eval.accuracy ? m : b, models[0])
    : null;

  const ctx: AppState = {
    dataset, textCol, labelCol, lmap, vocab, models, bestModel, predictions,
    setDataset: (rows,tc,lc,lm) => { setDs(rows); setTc(tc); setLc(lc); setLmap(lm); setModels([]); setPreds([]); },
    setVocab: v => setVocabState(v),
    addModel: m => setModels(prev => [...prev.filter(x=>x.algo!==m.algo), m]),
    clearModels: () => setModels([]),
    addPrediction: p => setPreds(prev => [...prev, p]),
    deletePrediction: id => setPreds(prev => prev.filter(p=>p.id!==id)),
  };

  const meta: Record<Screen,{title:string;sub:string}> = {
    home:          { title:"Fraud Detection System",   sub:"" },
    about:         { title:"About the System",         sub:"NB · Logistic Regression · SVM — how each algorithm works." },
    dataset:       { title:"Dataset",                  sub:"Upload CSV · 20,000+ rows supported · Auto-detects labels." },
    preprocessing: { title:"Text Preprocessing",       sub:"Real NLP pipeline: lowercase → stopwords → stemming → TF-IDF." },
    training:      { title:"Model Training",           sub:"Train Naive Bayes, Logistic Regression, and SVM — compare accuracy." },
    detection:     { title:"Fraud Detection",          sub:"Analyze articles with your trained model. Choose NB, LR, or SVM." },
    dashboard:     { title:"Analytics Dashboard",      sub:"Model accuracy, dataset stats, and prediction history." },
    results:       { title:"Prediction Results",       sub:"All analyzed articles · filter by Real/Fake · export CSV." },
  };

  return (
    <Ctx.Provider value={ctx}>
      <div className="flex h-screen w-full overflow-hidden" style={{ background:"#080c18", fontFamily:"Inter,sans-serif" }}>
        <Sidebar active={screen} onNav={setScreen} />
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {screen!=="home" && <Header title={meta[screen].title} sub={meta[screen].sub} />}
          {screen==="home"          && <HomeScreen onNav={setScreen} />}
          {screen==="about"         && <AboutScreen />}
          {screen==="dataset"       && <DatasetScreen />}
          {screen==="preprocessing" && <PreprocessingScreen />}
          {screen==="training"      && <TrainingScreen />}
          {screen==="detection"     && <DetectionScreen onNav={setScreen} />}
          {screen==="dashboard"     && <DashboardScreen />}
          {screen==="results"       && <ResultsScreen onNav={setScreen} />}
        </div>
      </div>
    </Ctx.Provider>
  );
}
